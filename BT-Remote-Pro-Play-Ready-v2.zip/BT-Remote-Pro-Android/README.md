# BT Remote Pro

En native Android-app som återskapar den mörka BT Remote Pro-layouten och använder Androids
`BluetoothHidDevice`-profil för att kunna uppträda som en Bluetooth HID-enhet.

## Viktigt om Bluetooth
Telefonen måste stödja Bluetooth HID Device (API 28+ och OEM-stöd). Android TV måste kunna
ta emot HID/keyboard/consumer-control. Parkoppla TV:n med telefonen först och välj sedan TV:n
i appen.

Detta är en riktig native-app, inte Web Bluetooth. Web Bluetooth i en vanlig HTML-sida kan
inte ersätta Androids HID Device-profil.

## Bygg
Öppna projektet i Android Studio med internetanslutning för att hämta Android Gradle Plugin
och AndroidX. Bygg sedan `app` som APK.

## Begränsning
HID-profiler och vilka consumer-control-kommandon en viss Android TV accepterar varierar
mellan TV-tillverkare/Android-versioner. Appen visar anslutningsstatus och använder standard
HID consumer-control rapporter.
